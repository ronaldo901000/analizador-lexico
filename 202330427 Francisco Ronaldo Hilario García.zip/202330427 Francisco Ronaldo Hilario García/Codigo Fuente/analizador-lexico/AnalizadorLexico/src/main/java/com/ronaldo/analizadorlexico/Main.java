package com.ronaldo.analizadorlexico;

import com.ronaldo.analizadorlexico.backend.Motor;

/**
 *
 * @author ronaldo
 */
public class Main {

    public static void main(String[] args) {
           Motor motor= new Motor();
           motor.iniciar();
    }
}
