package com.ronaldo.analizadorlexico.backend.exception;

/**
 *
 * @author ronaldo
 */
public class JsonException extends Exception{
       
       public JsonException(String mensaje){
              super(mensaje);
       }
       
}
